<?php
  // Create connection
$con = mysqli_connect('localhost', 'root', 'root','pw7');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

$query = 'SELECT * FROM book';
$data = mysqli_query($con, $query) ;
$json_response = array();
while ($row = mysqli_fetch_array($data)) {
  $p = array(
              "Book_id" => $row['book_id'],
              "Title" => $row['title'],
              "Year" => $row['year'],
              "Price" => $row['price'],
              "Category" => $row['category']
              );
  array_push($json_response,$p);
}
echo json_encode($json_response);
?>
