<!DOCTYPE html>
<html>
<head>
  <title>PW6</title>
  <link href="babynames.css" rel="stylesheet">
</head>
<body>
  <form name="showBabyNames" action="" method="POST">
    <p>Select a Year
    <select name="year">
      <option value="all" <?php if(isset($_POST["year"]) && $_POST["year"]=="all") { echo "selected"; } ?>>All</option>
      <option value="2011" <?php if(isset($_POST["year"]) && $_POST["year"]=="2011") { echo "selected"; } ?>>2011</option>
      <option value="2012" <?php if(isset($_POST["year"]) && $_POST["year"]=="2012") { echo "selected"; } ?>>2012</option>
      <option value="2013" <?php if(isset($_POST["year"]) && $_POST["year"]=="2013") { echo "selected"; } ?>>2013</option>
      <option value="2014" <?php if(isset($_POST["year"]) && $_POST["year"]=="2014") { echo "selected"; } ?>>2014</option>
      <option value="2015" <?php if(isset($_POST["year"]) && $_POST["year"]=="2015") { echo "selected"; } ?>>2015</option>
    </select></p><br>

    <p>Select a Gender
    <select name="gender">
      <option value="both" <?php if(isset($_POST["gender"]) && $_POST["gender"]=="both") { echo "selected"; } ?>>Both</option>
      <option value="m" <?php if(isset($_POST["gender"]) && $_POST["gender"]=="m") { echo "selected"; } ?>>Male</option>
      <option value="f" <?php if(isset($_POST["gender"]) && $_POST["gender"]=="f") { echo "selected"; } ?>>Female</option>
    </select></p><br>

    <input type="submit" value="Submit" name="report">

  </form>
</body>
</html>

<?php
$servername = "localhost";
$username = "root";
$password = "root";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['report'])) {
  $selectedYear = $_POST['year'];
  $selectedGender = $_POST['gender'];

  if($selectedYear == 'all' && $selectedGender == 'both') {
    $query = 'SELECT * FROM hw3.babynames WHERE gender = "m"';
    $data = mysqli_query($conn, $query) ;
    echo "&nbsp;&nbsp;&nbsp;&nbsp;<table>
              <tr>
              <th>Name</th>
              <th>Year</th>
              <th>Ranking</th>
              <th>Gender</th>
              </tr>";
                while ($row = mysqli_fetch_array($data)) {
                    echo "<tr>
                        <td>" . $row['name'] . "</td>
                        <td>" . $row['year'] . "</td>
                        <td>" . $row['ranking'] . "</td>
                        <td>" . $row['gender'] . "</td>
                      </tr>";
                 }
                 echo "</table>&nbsp;&nbsp;&nbsp;&nbsp;";

      $query1 = 'SELECT * FROM hw3.babynames WHERE gender = "f"';
      $data1 = mysqli_query($conn, $query1) ;
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<table>
              <tr>
              <th>Name</th>
              <th>Year</th>
              <th>Ranking</th>
              <th>Gender</th>
              </tr>";
                while ($row = mysqli_fetch_array($data1)) {
                    echo "<tr>
                          <td>" . $row['name'] . "</td>
                          <td>" . $row['year'] . "</td>
                          <td>" . $row['ranking'] . "</td>
                          <td>" . $row['gender'] . "</td>
                          </tr>";
                        }
                    echo "</table>";
    } // if ends

    else if($selectedYear == 'all' && !($selectedGender == 'both')) {
      $query5 = 'SELECT * FROM hw3.babynames WHERE gender = "'.$selectedGender.'"';
      $data5 = mysqli_query($conn, $query5) ;
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<table>
              <tr>
              <th>Name</th>
              <th>Year</th>
              <th>Ranking</th>
              <th>Gender</th>
              </tr>";
                while ($row = mysqli_fetch_array($data5)) {
                    echo "<tr>
                          <td>" . $row['name'] . "</td>
                          <td>" . $row['year'] . "</td>
                          <td>" . $row['ranking'] . "</td>
                          <td>" . $row['gender'] . "</td>
                          </tr>";
                        }
                    echo "</table>";
    } // else if ends

  else {
    if($selectedGender == 'both') {
      $query2 = 'SELECT * FROM hw3.babynames WHERE year = "'.$selectedYear.'" AND gender = "m"';
      $data2 = mysqli_query($conn, $query2) ;
      echo "&nbsp;&nbsp;&nbsp;&nbsp;<table>
                <tr>
                <th>Name</th>
                <th>Year</th>
                <th>Ranking</th>
                <th>Gender</th>
                </tr>";
                  while ($row = mysqli_fetch_array($data2)) {
                      echo "<tr>
                          <td>" . $row['name'] . "</td>
                          <td>" . $row['year'] . "</td>
                          <td>" . $row['ranking'] . "</td>
                          <td>" . $row['gender'] . "</td>
                        </tr>";
                   }
                   echo "</table>&nbsp;&nbsp;&nbsp;&nbsp;";

        $query4 = 'SELECT * FROM hw3.babynames WHERE year = "'.$selectedYear.'" AND gender = "f"';
        $data4 = mysqli_query($conn, $query4) ;
        echo "&nbsp;&nbsp;&nbsp;&nbsp;<table>
                <tr>
                <th>Name</th>
                <th>Year</th>
                <th>Ranking</th>
                <th>Gender</th>
                </tr>";
                  while ($row = mysqli_fetch_array($data4)) {
                      echo "<tr>
                            <td>" . $row['name'] . "</td>
                            <td>" . $row['year'] . "</td>
                            <td>" . $row['ranking'] . "</td>
                            <td>" . $row['gender'] . "</td>
                            </tr>";
                          }
                      echo "</table>";

    }  // Inner if ends
    else {
    $query3 = 'SELECT * FROM hw3.babynames WHERE year = "'.$selectedYear.'" AND gender = "'.$selectedGender.'"';
    $data3 = mysqli_query($conn, $query3) ;
    echo "&nbsp;&nbsp;&nbsp;&nbsp;<table>
            <tr>
            <th>Name</th>
            <th>Year</th>
            <th>Ranking</th>
            <th>Gender</th>
            </tr>";
              while ($row = mysqli_fetch_array($data3)) {
                  echo "<tr>
                        <td>" . $row['name'] . "</td>
                        <td>" . $row['year'] . "</td>
                        <td>" . $row['ranking'] . "</td>
                        <td>" . $row['gender'] . "</td>
                        </tr>";
                      }
                  echo "</table>";

                } // Inner else ends

              } // else ends

          }  // isset($_POST) ends
?>
