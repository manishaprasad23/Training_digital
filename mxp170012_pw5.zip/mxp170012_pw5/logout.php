<?php
session_start();
include('welcome.php');
if(session_destroy()) // Destroying All Sessions
{
  header("Location: login.html"); // Redirecting To Home Page
  exit();
}
?>
