<?php
session_start();
include('login.php');

if(!(isset($_SESSION['login_user']))){
  header("location: login.html");
  exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Your Home Page</title>
</head>
<body>

  <div>
    <h2>Welcome : <?php session_start();
     echo $_SESSION['login_user']; ?></h2>
     <h3>You visited this page <?php session_start();
      echo $_SESSION['login_count']; ?> times</h3>
      <a href="welcome.php">Click here to reload the page</a>
      <a href="logout.php">Log Out</a>
  </div>

</body>
</html>
