<?php
session_start();

$name = $email = $password = "";
$flag = "";
$count = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST["name"];
  $email = $_POST["email"];

  check_name($_POST["name"]);
  check_email($_POST["email"]);
  check_password($_POST["password"]);

}

if($flag == true) {
  $_SESSION['login_user']= $name;
  $_SESSION['login_email']= $email;
  $count = $count + 1;
  $_SESSION['login_count']= $count;
  header("location: welcome.php");
  exit();
}
else {
  header("location: login.html");
  exit();
}

function check_name($input_name) {
  if (empty($input_name)) {
    $flag = false;
  }
}

function check_email($input_email) {
  if (empty($input_email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $flag = false;
  }
}

function check_password($input_password) {
  if (empty($input_password) || strlen($input_password) < 6) {
    $flag = false;
  }
}

?>
