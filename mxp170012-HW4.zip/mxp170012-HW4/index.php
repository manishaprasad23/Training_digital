<?php

$url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$path = parse_url($url, PHP_URL_PATH);
$pathComponents = explode("/", trim($path, "/"));

// Create connection
$con = mysqli_connect('localhost', 'root', 'root','hw4');
if (!$con) {
  die('Could not connect: ' . mysqli_error($con));
}

if(sizeof($pathComponents) == 2) {
  $id = $pathComponents[1];

  $query = 'Select title, year, price, category, author_name from book inner join book_author
  on book.book_id = book_author.book_id
  inner join author on author.author_id = book_author.author_id
  where book.book_id ='.$id;
  $data = mysqli_query($con, $query) ;
  $json_response = array();
  while ($row = mysqli_fetch_array($data)) {
    $p = array(
                // "Book_id" => $row['book_id'],
                "Title" => $row['title'],
                "Year" => $row['year'],
                "Price" => $row['price'],
                "Category" => $row['category'],
                "Author(s)" => $row['author_name']
                );
    array_push($json_response,$p);
  }
  echo json_encode($json_response);
}

else {
  $query = 'SELECT * FROM book';
  $data = mysqli_query($con, $query) ;
  $json_response = array();
  while ($row = mysqli_fetch_array($data)) {
    $p = array(
                // "Book_id" => $row['book_id'],
                "Title" => $row['title'],
                // "Year" => $row['year'],
                "Price" => $row['price'],
                "Category" => $row['category']
                );
    array_push($json_response,$p);
  }
  echo json_encode($json_response);
}
?>
