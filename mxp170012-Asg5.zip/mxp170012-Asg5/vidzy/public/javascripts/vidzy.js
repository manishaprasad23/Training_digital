var app = angular.module('Vidzy', ['ngRoute', 'ngResource']);

app.config(['$routeProvider', function($routeProvider){
    $routeProvider
        .when('/', {
            templateUrl: 'partials/home.html',
            controller: 'HomeCtrl'
        })
        .when('/add-video', {
            templateUrl: 'partials/video-form.html',
            controller: 'AddVideoCtrl'
        })
        .when('/video/:id', {
	        templateUrl: 'partials/video-form.html',
	        controller: 'EditVideoCtrl'
    	})
    	.when('/video/delete/:id', {
	        templateUrl: 'partials/video-delete.html',
	        controller: 'DeleteVideoCtrl'
    	})
        .otherwise({
            redirectTo: '/'
        });
}]);

app.controller('HomeCtrl', ['$scope', '$resource', '$routeParams',
    function($scope, $resource, $routeParams){
        var Videos = $resource('/videos');
        Videos.query(function(videos){
            $scope.videos = videos;
        });

        // vd.get({ genre: $routeParams.sgenre }, function(video){
        //     $scope.video = video;
        // });

        // $scope.search = function(){
        // 	alert("Selected Genre : " + $scope.selectedGenre);
        //     var vd = $resource('/videos/:genre');
        // 	var genre = $scope.selectedGenre;
        // 	// alert(genre);
        //     vd.query({ genre: $routeParams.genre }, function(vds){
        //     $scope.vds = vds;
        //     alert(JSON.stringify($scope.vds));
        // 	});
        //     // });
        // };

        // $scope.search = function(){
        // 	// alert("Selected Genre : " + $scope.selectedGenre);
        // 	var Videos = $resource('/videos/:genre');
        // 	Videos.get({ genre: $routeParams.genre }, function(video){
        // 		$scope.video = video;
        // 	});
        // };
  }]);

app.controller('AddVideoCtrl', ['$scope', '$resource', '$location',
    function($scope, $resource, $location){
        $scope.save = function(){
            var Videos = $resource('/videos');
            Videos.save($scope.video, function(){
                $location.path('/');
            });
        };
    }]);

app.controller('EditVideoCtrl', ['$scope', '$resource', '$location', '$routeParams',
    function($scope, $resource, $location, $routeParams){	
        var Videos = $resource('/videos/:id', { id: '@_id' }, {
            update: { method: 'PUT' }
        });

        Videos.get({ id: $routeParams.id }, function(video){
            $scope.video = video;
        });

        $scope.save = function(){
            Videos.update($scope.video, function(){
                $location.path('/');
            });
        };
    }]);

app.controller('DeleteVideoCtrl', ['$scope', '$resource', '$location', '$routeParams',
    function($scope, $resource, $location, $routeParams){
        var Videos = $resource('/videos/:id');

        Videos.get({ id: $routeParams.id }, function(video){
            $scope.video = video;
        })

        $scope.delete = function(){
            Videos.delete({ id: $routeParams.id }, function(video){
                $location.path('/');
            });
        }
    }]);