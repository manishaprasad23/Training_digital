$(document).ready(function() {
  var k = 0, m = 0, n = 0;
  $.ajax({
    type: 'GET',
    url: 'movies.xml',
    dataType: 'xml',
    success: function(xmlData) {
      $(xmlData).find('movie').each(function(){
        var title = $(this).find("title").text();
        var director = $(this).find("director").text();
        var description = $(this).find("synopsis").text();
        var score = $(this).find("score").text();

        var x = xmlData.getElementsByTagName('cast')[k++];
        var i, txt="";
        var y = x.getElementsByTagName('person');
        for (i = 0; i < y.length; i++) {
          if(i == y.length - 1) {
            txt += y[i].getAttribute('name');
          }
          else {
          txt += y[i].getAttribute('name') + ", ";
        }
      }

        var a = xmlData.getElementsByTagName('movie')[m++];
        var j, t1="";
        var b = a.getElementsByTagName('genre');
        for(j = 0; j < b.length; j++) {
          if(j == b.length - 1) {
            t1 += xmlData.getElementsByTagName("genre")[n++].childNodes[0].nodeValue;
          }
          else {
            t1 += xmlData.getElementsByTagName("genre")[n++].childNodes[0].nodeValue + ", ";
       }
    }

        var output = '<tr>';
        output += '<td>'+title+'</td>';
        output += '<td>'+t1+'</td>';
        output += '<td>'+director+'</td>';
        output += '<td>'+txt+'</td>';
        output += '<td>'+description+'</td>';
        output += '<td>'+score+'</td>';
        output += '</tr>';
        $("tbody").append(output);

      }); // each ends

    } // success ends

  });  // Ajax ends

});  //Document.ready ends
