function Validate() {
  var firstname = document.getElementById("firstname").value;
  var lastname = document.getElementById("lastname").value;
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  var cnfpassword = document.getElementById("cnfpassword").value;

  // Validation conditions

  if(firstname !== "") {
    if(lastname !== "") {
      if(email !== "") {
        if(password !== "") {
          if(cnfpassword !== "") {
            if(cnfpassword == password) {
              if (document.getElementById("useragree").checked) {
                alert("Form has been submitted successfully");
                return true;
              }
              else {
                alert("Please agree to the Terms and Privacy Policy");
                return false;
              }
          }
          else {
            alert("Passwords do not match");
            document.getElementById('cnfpassword').style.borderColor = "red";
            return false;
          }
        }
          else {
            alert("Please confirm the password");
            document.getElementById('cnfpassword').style.borderColor = "red";
            return false;
          }
        }

        else {
          alert("Password is required");
          document.getElementById('password').style.borderColor = "red";
          return false;
        }
      }
      else {
        alert("Email is required");
        document.getElementById('email').style.borderColor = "red";
        return false;
      }

    }
    else {
      alert("Last Name is required");
      document.getElementById('lastname').style.borderColor = "red";
      return false;
    }

  }
  else {
    alert("First Name is required");
    document.getElementById('firstname').style.borderColor = "red";
    return false;
  }

}  // Validate ends

function firstnameChngd(firstname) {
    document.getElementById('firstname').style.borderColor = "";
}

function lastnameChngd(lastname) {
    document.getElementById('lastname').style.borderColor = "";
}
function emailChngd(email) {
    document.getElementById('email').style.borderColor = "";
}
function passwordChngd(password) {
    document.getElementById('password').style.borderColor = "";
}
function cnfpasswordChngd(cnfpassword) {
    document.getElementById('cnfpassword').style.borderColor = "";
}
