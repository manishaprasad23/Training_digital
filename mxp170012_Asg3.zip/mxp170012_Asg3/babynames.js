function getData() {

    var year = document.getElementById("year").value;
    var gender = document.getElementById("gender").value;

        if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest();
        } else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("showResults").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","babynames.php?q="+year+"&r="+gender,true);
        // xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send();
}
